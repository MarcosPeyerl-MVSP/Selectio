import {
  addDoc,
  collection,
  doc,
  getDocs,
  limit,
  query,
  serverTimestamp,
  updateDoc,
  where
} from 'firebase/firestore'
import { db } from './firebase'

const indicacoesCollection = collection(db, 'indicacoes')

const timestampToValue = (value) => {
  if (!value) return null
  if (typeof value.toDate === 'function') return value.toDate().toISOString()
  return value
}

const parseMoneyValue = (value) => {
  const normalized = String(value || '')
    .replace(/[^\d,.-]/g, '')
    .replace(/\./g, '')
    .replace(',', '.')

  return Number(normalized || 0)
}

const mapIndicacaoDoc = (snapshot) => {
  if (!snapshot.exists()) return null

  const data = snapshot.data()

  return {
    id: snapshot.id,
    ...data,
    recompensaValor: Number(data.recompensaValor || parseMoneyValue(data.recompensa)),
    criadoEm: timestampToValue(data.criadoEm),
    atualizadoEm: timestampToValue(data.atualizadoEm)
  }
}

const sortByCreatedDesc = (a, b) => {
  const dateA = new Date(a.criadoEm || 0).getTime()
  const dateB = new Date(b.criadoEm || 0).getTime()
  return dateB - dateA
}

export const registrarIndicacao = async (dados) => {
  const docRef = await addDoc(indicacoesCollection, {
    ...dados,
    status: dados.status || 'indicado',
    recompensaValor: Number(dados.recompensaValor || parseMoneyValue(dados.recompensa)),
    criadoEm: serverTimestamp(),
    atualizadoEm: serverTimestamp()
  })

  return docRef.id
}

export const atualizarStatusIndicacaoPorCandidato = async (candidatoId, status) => {
  if (!candidatoId) return

  const snapshot = await getDocs(query(indicacoesCollection, where('candidatoId', '==', candidatoId), limit(10)))

  await Promise.all(snapshot.docs.map((indicacaoDoc) => (
    updateDoc(doc(db, 'indicacoes', indicacaoDoc.id), {
      status,
      atualizadoEm: serverTimestamp()
    })
  )))
}

export const listarIndicacoesPorIndicador = async (indicadorId) => {
  if (!indicadorId) return []

  const snapshot = await getDocs(query(indicacoesCollection, where('indicadorId', '==', indicadorId), limit(200)))
  return snapshot.docs.map(mapIndicacaoDoc).filter(Boolean).sort(sortByCreatedDesc)
}

export const buscarStatusIndicador = async (indicadorId) => {
  const indicacoes = await listarIndicacoesPorIndicador(indicadorId)
  const totalIndicacoes = indicacoes.length
  const vagasSucesso = indicacoes.filter((indicacao) => indicacao.status === 'contratado').length
  const vagasCanceladas = indicacoes.filter((indicacao) => ['cancelado', 'recusado'].includes(indicacao.status)).length
  const vagasAtivas = indicacoes.filter((indicacao) => !['contratado', 'cancelado', 'recusado'].includes(indicacao.status)).length
  const valorRecebido = indicacoes
    .filter((indicacao) => indicacao.status === 'contratado')
    .reduce((total, indicacao) => total + Number(indicacao.recompensaValor || 0), 0)
  const valorPendente = indicacoes
    .filter((indicacao) => !['contratado', 'cancelado', 'recusado'].includes(indicacao.status))
    .reduce((total, indicacao) => total + Number(indicacao.recompensaValor || 0), 0)

  return {
    totalIndicacoes,
    vagasAtivas,
    vagasCanceladas,
    vagasSucesso,
    valorRecebido,
    valorPendente,
    taxaSucesso: totalIndicacoes ? Number(((vagasSucesso * 100) / totalIndicacoes).toFixed(1)) : 0
  }
}
