// Objetivo do arquivo: renderizar a página de login da aplicação Selectio.
// A página autentica usuários dos tipos indicador e empresa, controla redirecionamento
// após login e mantém a sessão no localStorage.

import './Login.css'
import Navbar from '../../components/Navbar/Navbar/Navbar'
import Footer from '../../components/Footer/Footer'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { FaApple, FaEye, FaEyeSlash, FaGoogle, FaLock, FaUser } from 'react-icons/fa'
import {
  GoogleAuthProvider,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut
} from 'firebase/auth'
import { auth } from '../../services/firebase'
import { getFirebaseAuthErrorMessage, isFirebaseAuthError } from '../../services/authErrors'
import { buscarPerfilUsuario } from '../../services/firestoreUsers'

function Login() {
  // Armazena os dados digitados no formulário de login.
  const [form, setForm] = useState({ login: '', senha: '' })

  // Armazena mensagens de erro exibidas ao usuário.
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  // Controla o estado de carregamento durante a tentativa de autenticação.
  const [loading, setLoading] = useState(false)

  // Controla se o campo de senha será exibido como texto ou senha mascarada.
  const [showPassword, setShowPassword] = useState(false)

  // Hook usado para redirecionar o usuário após login ou quando já existe sessão.
  const navigate = useNavigate()

  // Hook usado para ler parâmetros da URL atual.
  const location = useLocation()

  // Parâmetro opcional usado para redirecionar o usuário após autenticação.
  const redirectTo = new URLSearchParams(location.search).get('redirect')

  useEffect(() => {
    // Regra de sessão: se já existir usuário indicador salvo, redireciona
    // para o destino informado ou para o painel do indicador.
    if (localStorage.getItem('indicadorUser')) {
      navigate(redirectTo || '/painel/indicador')
      return
    }

    // Regra de sessão: se já existir usuário empresa salvo, redireciona
    // para o destino informado ou para o painel da empresa.
    if (localStorage.getItem('empresaUser')) {
      navigate(redirectTo || '/painel/empresa')
    }
  }, [navigate, redirectTo])

  // Responsabilidade: atualizar o estado do formulário conforme o usuário digita.
  const handleChange = (event) => {
    const { name, value } = event.target
    setForm((prev) => ({ ...prev, [name]: value }))
  }

  // Responsabilidade: validar o formulário e executar o fluxo de autenticação.
  const handleSubmit = async (event) => {
    event.preventDefault()
    setError('')
    setSuccess('')

    const login = form.login.trim()
    const senha = form.senha

    // Validação obrigatória: login e senha precisam estar preenchidos.
    if (!login || !senha) {
      setError('Preencha e-mail e senha.')
      return
    }

    let firebaseAuthenticated = false

    try {
      setLoading(true)

      // Firebase Auth e a primeira camada de autenticacao do login.
      const firebaseCredential = await signInWithEmailAndPassword(auth, login, senha)
      const firebaseUid = firebaseCredential.user.uid
      firebaseAuthenticated = true

      // Busca o perfil do usuario no Firestore apos autenticar no Firebase.
      const perfil = await buscarPerfilUsuario(firebaseUid)

      if (!perfil) {
        await signOut(auth)
        setError('Sua conta existe no Firebase, mas ainda nao possui perfil no Selectio.')
        setLoading(false)
        return
      }

      if (perfil.tipo === 'indicador') {
        // Regra de sessão: salva indicador autenticado e remove sessão de empresa.
        localStorage.setItem('indicadorUser', JSON.stringify(perfil))
        localStorage.removeItem('empresaUser')
        navigate(redirectTo || '/painel/indicador')
        return
      }

      // Apenas perfis conhecidos entram na aplicacao.
      if (perfil.tipo !== 'empresa') {
        await signOut(auth)

        // Exibe uma mensagem amigavel para perfil inconsistente.
        setError('Perfil de usuario invalido. Entre em contato com o suporte da Selectio.')
        setLoading(false)
        return
      }

      // Regra de sessão: salva empresa autenticada e remove sessão de indicador.
      localStorage.setItem('empresaUser', JSON.stringify(perfil))
      localStorage.removeItem('indicadorUser')
      navigate(redirectTo || '/painel/empresa')
    } catch (error) {
      // Tratamento de erro para falha de conexão com o servidor.
      if (isFirebaseAuthError(error)) {
        setError(getFirebaseAuthErrorMessage(error))
      } else {
        if (firebaseAuthenticated) {
          await signOut(auth).catch(() => {})
        }

        setError('Nao foi possivel buscar seu perfil no Firestore. Verifique sua conexao e tente novamente.')
      }

      setLoading(false)
    }
  }

  const handleGoogleLogin = async () => {
    setError('')
    setSuccess('')

    try {
      setLoading(true)

      const provider = new GoogleAuthProvider()
      provider.setCustomParameters({ prompt: 'select_account' })

      const firebaseCredential = await signInWithPopup(auth, provider)
      const perfil = await buscarPerfilUsuario(firebaseCredential.user.uid)

      if (!perfil) {
        await signOut(auth)
        setError('Esta conta Google ainda nao possui perfil no Selectio. Conclua o cadastro primeiro.')
        setLoading(false)
        return
      }

      if (perfil.tipo === 'indicador') {
        localStorage.setItem('indicadorUser', JSON.stringify(perfil))
        localStorage.removeItem('empresaUser')
        navigate(redirectTo || '/painel/indicador')
        return
      }

      if (perfil.tipo === 'empresa') {
        localStorage.setItem('empresaUser', JSON.stringify(perfil))
        localStorage.removeItem('indicadorUser')
        navigate(redirectTo || '/painel/empresa')
        return
      }

      await signOut(auth)
      setError('Perfil de usuario invalido. Entre em contato com o suporte da Selectio.')
      setLoading(false)
    } catch (error) {
      if (isFirebaseAuthError(error)) {
        setError(getFirebaseAuthErrorMessage(error))
      } else {
        setError('Nao foi possivel entrar com Google. Verifique sua conexao e tente novamente.')
      }

      setLoading(false)
    }
  }

  const handlePasswordReset = async () => {
    setError('')
    setSuccess('')

    const email = form.login.trim()

    if (!email) {
      setError('Informe seu e-mail para receber o link de redefinicao.')
      return
    }

    try {
      setLoading(true)
      await sendPasswordResetEmail(auth, email)
      setSuccess('Se este e-mail estiver cadastrado, enviaremos um link de redefinição.')
    } catch (error) {
      if (isFirebaseAuthError(error)) {
        setError(getFirebaseAuthErrorMessage(error))
      } else {
        setError('Nao foi possivel solicitar a redefinicao agora. Verifique sua conexao e tente novamente.')
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      {/* Componente de navegação principal da aplicação. */}
      <Navbar />

      <main className="login-container">
        <div className="login-card">
          <h1>Entre na sua conta</h1>

          {/* Formulário principal de autenticação. */}
          <form className="login-form" onSubmit={handleSubmit}>
            <label>
              E-mail
              <div className="input-group">
                <span className="input-icon"><FaUser /></span>
                <input
                  name="login"
                  type="email"
                  placeholder="seu@email.com"
                  value={form.login}
                  onChange={handleChange}
                />
              </div>
            </label>

            <label>
              Senha
              <div className="input-group">
                <span className="input-icon"><FaLock /></span>
                <input
                  name="senha"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="********"
                  value={form.senha}
                  onChange={handleChange}
                />

                {/* Botão para alternar visibilidade da senha. */}
                <button
                  type="button"
                  className="password-visibility"
                  onClick={() => setShowPassword((visible) => !visible)}
                  aria-label={showPassword ? 'Ocultar senha' : 'Mostrar senha'}
                >
                  {showPassword ? <FaEyeSlash /> : <FaEye />}
                </button>
              </div>

              {/* Link visual de recuperação de senha, sem rota definida neste código. */}
              <button
                type="button"
                className="forgot-password"
                onClick={handlePasswordReset}
                disabled={loading}
              >
                Esqueceu sua senha?
              </button>
            </label>

            {/* Exibe mensagens de erro de validação, autenticação ou conexão. */}
            {error && <p className="login-error">{error}</p>}
            {success && <p className="login-success">{success}</p>}

            <button type="submit" className="login-button" disabled={loading}>
              {loading ? 'Entrando...' : 'Entrar ->'}
            </button>
          </form>

          {/* Separador visual entre login por formulário e botões sociais. */}
          <div className="login-divider">
            <span>ou continue com</span>
          </div>

          {/* Botões sociais exibidos na interface; não há integração implementada neste código. */}
          <div className="social-login">
            <button type="button" className="google" onClick={handleGoogleLogin} disabled={loading}>
              <FaGoogle /> Google
            </button>
            <button type="button" className="apple"><FaApple /> Apple</button>
          </div>

          {/* Link para página de cadastro. */}
          <p className="register-link">
            Nao tem uma conta? <Link to="/cadastro">Cadastre-se</Link>
          </p>
        </div>
      </main>

      {/* Componente de rodapé da aplicação. */}
      <Footer />
    </>
  )
}

export default Login
